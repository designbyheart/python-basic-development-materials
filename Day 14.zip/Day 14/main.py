# from bookstore import Bookstore
from book import Book
from category import Category
from user import User

from ui.bookstore_ui import BookstoreUI
import tkinter as tk
from tkinter import messagebox, Listbox, Scrollbar


def runApp():
    root = tk.Tk()
    app = BookstoreUI(root)
    root.mainloop()


if __name__ == "__main__":
    runApp()
