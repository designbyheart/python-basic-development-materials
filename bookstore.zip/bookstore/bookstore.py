from book import Book
from category import Category
from user import User
from utils.file_manager import load_csv, save_csv
from utils.constants import BOOKS_FILE, CATEGORIES_FILE, USERS_FILE, RENTED_BOOKS_FILE


class Bookstore:
    def __init__(self):
        self.books = load_csv(BOOKS_FILE, Book)
        self.categories = load_csv(CATEGORIES_FILE, Category)
        self.users = load_csv(USERS_FILE, User)
        self.rented_books = load_csv(RENTED_BOOKS_FILE)

    def list_books(self):
        return self.books

    def search_books(self, keyword):
        return [book for book in self.books if keyword.lower() in book.title.lower()]

    def add_book(self, book):
        self.books.append(book)
        save_csv(BOOKS_FILE, self.books)

    def update_book(self, book_id, new_data):
        for book in self.books:
            if book.book_id == book_id:
                book.title = new_data.get("title", book.title)
                book.author = new_data.get("author", book.author)
                save_csv(BOOKS_FILE, self.books)
                return True
        return False

    def delete_book(self, book_id):
        self.books = [book for book in self.books if book.book_id != book_id]
        save_csv(BOOKS_FILE, self.books)

    def rent_book(self, user_id, book_id):
        for book in self.books:
            if book.book_id == book_id and book.available:
                book.available = False
                self.rented_books.append({"user_id": user_id, "book_id": book_id})
                save_csv(RENTED_BOOKS_FILE, self.rented_books)
                save_csv(BOOKS_FILE, self.books)
                return True
        return False

    def return_book(self, user_id, book_id):
        self.rented_books = [
            record
            for record in self.rented_books
            if not (record["user_id"] == user_id and record["book_id"] == book_id)
        ]
        for book in self.books:
            if book.book_id == book_id:
                book.available = True
                break
        save_csv(RENTED_BOOKS_FILE, self.rented_books)
        save_csv(BOOKS_FILE, self.books)
