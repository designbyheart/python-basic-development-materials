from bookstore import Bookstore
from book import Book
from category import Category
from user import User


def main():
    store = Bookstore()
    # Example: add new book
    new_book = Book(
        book_id="1",
        title="Python Programming",
        author="John Doe",
        category_id="1",
        publication_date="2019-07-11",
    )
    store.add_book(new_book)

    # Example: list books
    books = store.list_books()
    for book in books:
        print(book.to_dict())

    # Add other interactions here for testing each method


if __name__ == "__main__":
    main()
