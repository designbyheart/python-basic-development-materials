# Constants
BOOKS_FILE = "data/books.csv"
CATEGORIES_FILE = "data/categories.csv"
USERS_FILE = "data/users.csv"
RENTED_BOOKS_FILE = "data/rented_books.csv"
